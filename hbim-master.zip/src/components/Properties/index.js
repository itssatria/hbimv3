import Properties from './Properties';

export default Properties;
