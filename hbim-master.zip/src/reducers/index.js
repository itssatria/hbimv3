import viewerReducer from './viewerReducer';
export default viewerReducer;
